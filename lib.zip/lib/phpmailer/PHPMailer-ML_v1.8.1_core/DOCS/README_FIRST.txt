The ZIP file you downloaded is complete for a NEW installation.
If you are upgrading from a previous version, please visit the
documentation site:
PHPMailer-ML Upgrading
http://www.worxware.com/kb/index.php/category/phpmailerml
-- please note, to avoid overwritting files when upgrading
   - inc.settings.php has been renamed to inc.settings.default.php
   - inc.settings_db.php has been renamed to inc.settings_db.default.php
   - inc.settings_smtp.php has been renamed to inc.settings_smtp.default.php
   check the documentation site for upgrade instruction ... if over
   versions of these files have been updated, the instructions will be
   on the documentation site.

Starting with PHPMailer-ML version 1.8, we have removed all the
user documentation, changelogs, etc. and put them into one single
area to make documentation updating easier.

You can now find the PHPMailer-ML documentation at our new
knowledgebase website:

http://www.worxware.com/kb/

More specifically:

PHPMailer-ML Installation & Notes:
http://www.worxware.com/kb/index.php/category/phpmailerml

PHPMailer-ML User Documentation:
http://www.worxware.com/kb/index.php/category/mlusing

Enjoy!
Andy
