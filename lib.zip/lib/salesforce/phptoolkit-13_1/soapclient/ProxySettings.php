<?php
class ProxySettings {
  public $host;
  public $port;
  public $login;
  public $password;
}
?>